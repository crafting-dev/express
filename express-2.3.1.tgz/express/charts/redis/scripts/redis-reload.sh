#!/bin/sh

set -ex

LAST_DIGEST=

while true; do
    DIGEST="$(sha256sum <"$TLS_CERT_FILE" | cut -d ' ' -f 1)"
    [[ -n "$DIGEST" && "$LAST_DIGEST" == "$DIGEST" ]] || {
        redis-cli "$@" config set tls-cert-file "$TLS_CERT_FILE"
        LAST_DIGEST="$DIGEST"
    }
    sleep ${TLS_CHECK_INTERVAL:-60}
done
