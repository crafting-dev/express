#!/bin/sh

set -ex

SOCK=/shared/haproxy-admin.sock
CERT_FILE=/shared/tls.pem
CA_FILE=/shared/ca.pem

if [[ "$1" == "init" ]]; then
    cat "$TLS_CERT_FILE" "$TLS_KEY_FILE" >$CERT_FILE
    cp -f "$TLS_CA_FILE" $CA_FILE
    exit 0
fi

LAST_DIGEST=

while true; do
    DIGEST="$(sha256sum <"$TLS_CERT_FILE" | cut -d ' ' -f 1)"
    [[ -n "$DIGEST" && "$LAST_DIGEST" == "$DIGEST" ]] || {
        cat "$TLS_CERT_FILE" "$TLS_KEY_FILE" >$CERT_FILE
        chmod 0600 $CERT_FILE
        printf "set ssl cert $CERT_FILE <<\n%s\n\n" "$(cat $CERT_FILE)" | socat stdio "$SOCK"
        printf "commit ssl cert $CERT_FILE\n" | socat stdio "$SOCK"
        printf "set ssl ca-file $CA_FILE <<\n%s\n\n" "$(cat $TLS_CA_FILE)" | socat stdio "$SOCK"
        printf "commit ssl ca-file $CA_FILE\n" | socat stdio "$SOCK"
        LAST_DIGEST="$DIGEST"
    }
    sleep ${TLS_CHECK_INTERVAL:-60}
done
